#!/usr/bin/env bash
# scripts/build.sh — build the DotSync server binary and CLI for all platforms
set -euo pipefail

VERSION="${VERSION:-v0.1.0-beta}"
LDFLAGS="-s -w -X github.com/Pruthviraj36/dotsync/cli/cmd.Version=${VERSION}"

echo "🔨 Building DotSync ${VERSION}"
echo ""

# ── Server ────────────────────────────────────────────────────────────────────
echo "→ Server binary (linux/amd64)..."
GOOS=linux GOARCH=amd64 go build -ldflags="${LDFLAGS}" -o dist/dotsync-server-linux-amd64 ./cmd/dotsync

echo "→ Server binary (current platform)..."
go build -ldflags="${LDFLAGS}" -o dist/dotsync-server ./cmd/dotsync

# ── CLI ───────────────────────────────────────────────────────────────────────
echo ""
mkdir -p dist/tmp

echo "→ CLI (linux/amd64)..."
GOOS=linux GOARCH=amd64 go build -ldflags="${LDFLAGS}" -o dist/tmp/dotsync .
tar -czf dist/dotsync-linux-amd64.tar.gz -C dist/tmp dotsync
rm dist/tmp/dotsync

echo "→ CLI (darwin/amd64)..."
GOOS=darwin GOARCH=amd64 go build -ldflags="${LDFLAGS}" -o dist/tmp/dotsync .
tar -czf dist/dotsync-darwin-amd64.tar.gz -C dist/tmp dotsync
rm dist/tmp/dotsync

echo "→ CLI (darwin/arm64 — Apple Silicon)..."
GOOS=darwin GOARCH=arm64 go build -ldflags="${LDFLAGS}" -o dist/tmp/dotsync .
tar -czf dist/dotsync-darwin-arm64.tar.gz -C dist/tmp dotsync
rm dist/tmp/dotsync

echo "→ CLI (windows/amd64)..."
GOOS=windows GOARCH=amd64 go build -ldflags="${LDFLAGS}" -o dist/tmp/dotsync.exe .
zip -jq dist/dotsync-windows-amd64.zip dist/tmp/dotsync.exe
rm dist/tmp/dotsync.exe

rmdir dist/tmp

echo ""
echo "→ Generating checksums.txt..."
( cd dist && sha256sum dotsync-* > checksums.txt )

echo ""
echo "✅ Build complete. Artifacts in ./dist/"
ls -lh dist/
